package com.infy.stg;

import org.apache.poi.openxml4j.exceptions.InvalidFormatException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;

import java.io.File;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.*;
import java.util.concurrent.atomic.AtomicReference;

@RestController
@RequestMapping("/doc-zoning")
@CrossOrigin(origins = "*")
public class Controller {
    @PostMapping("/upload")
    public void upload(@RequestParam("file") MultipartFile file) throws Exception, IOException, InvalidFormatException {
        // Creating a Workbook from an Excel file (.xls or .xlsx)
        Path tempDir = Files.createTempDirectory("");
        File tempFile = tempDir.resolve(file.getOriginalFilename()).toFile();
        file.transferTo(tempFile);
    }

    @GetMapping("/counts")
    public void getCounts() throws IOException {
    }
}