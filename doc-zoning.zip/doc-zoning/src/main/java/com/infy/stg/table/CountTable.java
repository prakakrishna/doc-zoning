package com.infy.stg.table;

import javax.persistence.*;
import java.util.Date;
import java.util.zip.DeflaterOutputStream;

@Entity
@Table(name="count")

public class CountTable {
    @Id
    @GeneratedValue(generator = "count_seq")
    @SequenceGenerator(name="count_seq", sequenceName = "COUNT_SEQ")
    @Column(name="id")
    Long id;
    @Column(name="ispr")
    Integer ispr;
    @Column(name="sdr")
    Integer sdr;
    @Column(name="reject_inv_shipped")
    Integer reject_inv_shipped;
    @Column(name="reject_inv_pending")
    Integer reject_inv_pending;
    @Column(name="truck_received")
    Integer truck_received;
    @Column(name="trolley_returned")
    Integer trolley_returned;
    @Column(name="bins_returned")
    Integer bins_returned;
    @Column(name="is_active")
    Character is_active;
    @Column(name="date")
    Date date;
    @Column(name="created_date")
    Date created_date;

    public Long getId() {
        return id;
    }
    public void setId(Long id) {
        this.id = id;
    }
    public Integer getIspr() {
        return ispr;
    }
    public void setIspr(Integer ispr) {
        this.ispr = ispr;
    }
    public Integer getSdr() {
        return sdr;
    }
    public void setSdr(Integer sdr) {
        this.sdr = sdr;
    }
    public Integer getReject_inv_shipped() {
        return reject_inv_shipped;
    }
    public void setReject_inv_shipped(Integer reject_inv_shipped) {
        this.reject_inv_shipped = reject_inv_shipped;
    }
    public Integer getReject_inv_pending() {
        return reject_inv_pending;
    }
    public void setReject_inv_pending(Integer reject_inv_pending) {
        this.reject_inv_pending = reject_inv_pending;
    }
    public Integer getTruck_received() {
        return truck_received;
    }
    public void setTruck_received(Integer truck_received) {
        this.truck_received = truck_received;
    }
    public Integer getTrolley_returned() {
        return trolley_returned;
    }
    public void setTrolley_returned(Integer trolley_returned) {
        this.trolley_returned = trolley_returned;
    }
    public Integer getBins_returned() {
        return bins_returned;
    }
    public void setBins_returned(Integer bins_returned) {
        this.bins_returned = bins_returned;
    }
    public Character getIs_active() {
        return is_active;
    }
    public void setIs_active(Character is_active) {
        this.is_active = is_active;
    }
    public Date getDate() {
        return date;
    }
    public void setDate(Date date) {
        this.date = date;
    }
    public Date getCreated_date() {
        return created_date;
    }
    public void setCreated_date(Date created_date) {
        this.created_date = created_date;
    }
}